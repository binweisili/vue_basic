export default [
    {
      id: 1,
      name: '家用电器',
      subcategories: [
        { id: 101, name: '电水壶', image: 'https://via.placeholder.com/80x80?text=Kettle' },
        { id: 102, name: '电饭煲', image: 'https://via.placeholder.com/80x80?text=Rice+Cooker' },
        { id: 103, name: '微波炉', image: 'https://via.placeholder.com/80x80?text=Microwave' }
      ]
    },
    {
      id: 2,
      name: '手机数码',
      subcategories: [
        { id: 201, name: '手机', image: 'https://via.placeholder.com/80x80?text=Phone' }
      ]
    },
    {
      id: 3,
      name: '家电办公',
      subcategories: [
        { id: 301, name: '料理机', image: 'https://via.placeholder.com/80x80?text=Blender' },
        { id: 302, name: '豆浆机', image: 'https://via.placeholder.com/80x80?text=Soy+Milk' },
        { id: 303, name: '电烤箱', image: 'https://via.placeholder.com/80x80?text=Oven' }
      ]
    },
    {
      id: 4,
      name: '电脑办公',
      subcategories: [
        { id: 401, name: '显卡', image: 'https://via.placeholder.com/80x80?text=GPU' },
        { id: 402, name: '电竞鼠标', image: 'https://via.placeholder.com/80x80?text=Mouse' },
        { id: 403, name: '游戏本', image: 'https://via.placeholder.com/80x80?text=Gaming+Laptop' }
      ]
    },
    {
      id: 5,
      name: '个人清洁'
    },
    {
      id: 6,
      name: '汽车生活'
    },
    {
      id: 7,
      name: '男装'
    },
    {
      id: 8,
      name: '女装'
    },
    {
      id: 9,
      name: '男鞋'
    },
    {
      id: 10,
      name: '母婴童装'
    },
    {
      id: 11,
      name: '个人清洁'
    }
  ]
  